import 'react-native-gesture-handler';
import React from 'react';

import { NavigationContainer } from '@react-navigation/native';
import { createDrawerNavigator } from '@react-navigation/drawer';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';

import { MaterialCommunityIcons } from '@expo/vector-icons';

import RPGStack from './src/Rotas/RPGStack';
import AcaoStack from './src/Rotas/AcaoStack';
import TerrorStack from './src/Rotas/TerrorStack';
import Acao from './src/Telas/Acao';
import Terror from './src/Telas/Terror';

const Drawer = createDrawerNavigator();
const Tab = createBottomTabNavigator();

function Tabs() {
  return (
    <Tab.Navigator
      screenOptions={{
        headerStyle: { backgroundColor: '#161B22' },
        headerTintColor: '#fff',
        tabBarStyle: { backgroundColor: '#161B22' },
        tabBarActiveTintColor: '#66C0F4',
      }}
    >
      <Tab.Screen
        name="RPG"
        component={RPGStack}
        options={{
          tabBarIcon: ({ color, size }) => (
            <MaterialCommunityIcons name="sword-cross" size={size} color={color} />
          ),
        }}
      />

      <Tab.Screen
        name="Ação"
        component={AcaoStack}
        options={{
          tabBarIcon: ({ color, size }) => (
            <MaterialCommunityIcons name="lightning-bolt" size={size} color={color} />
          ),
        }}
      />

      <Tab.Screen
        name="Terror"
        component={TerrorStack}
        options={{
          tabBarIcon: ({ color, size }) => (
            <MaterialCommunityIcons name="ghost" size={size} color={color} />
          ),
        }}
      />
    </Tab.Navigator>
  );
}

export default function App() {
  return (
    <NavigationContainer>
      <Drawer.Navigator
        screenOptions={{
          headerStyle: { backgroundColor: '#161B22' },
          headerTintColor: '#fff',
          drawerStyle: { backgroundColor: '#0B0F14' },
          drawerActiveTintColor: '#66C0F4',
        }}
      >
        <Drawer.Screen
          name="Home"
          component={Tabs}
          options={{
            drawerIcon: ({ color, size }) => (
              <MaterialCommunityIcons name="view-dashboard" size={size} color={color} />
            ),
          }}
        />

        <Drawer.Screen
          name="RPG"
          component={RPGStack}
          options={{
            drawerIcon: ({ color, size }) => (
              <MaterialCommunityIcons name="sword-cross" size={size} color={color} />
            ),
          }}
        />

        <Drawer.Screen
          name="Ação"
          component={Acao}
          options={{
            drawerIcon: ({ color, size }) => (
              <MaterialCommunityIcons name="lightning-bolt" size={size} color={color} />
            ),
          }}
        />

        <Drawer.Screen
          name="Terror"
          component={Terror}
          options={{
            drawerIcon: ({ color, size }) => (
              <MaterialCommunityIcons name="ghost" size={size} color={color} />
            ),
          }}
        />
      </Drawer.Navigator>
    </NavigationContainer>
  );
}