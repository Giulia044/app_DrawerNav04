import React, { useState } from 'react';
import { ScrollView, View, Text, TextInput, FlatList } from 'react-native';

import { MaterialCommunityIcons } from '@expo/vector-icons';
import estilos from '../styles/estilos';

export default function Terror() {
  const [favorito, setFavorito] = useState('');

  const jogos = [
    { id: '1', nome: 'Resident Evil 4' },
    { id: '2', nome: 'Silent Hill 2' },
    { id: '3', nome: 'Outlast' },
    { id: '4', nome: 'Dead Space' },
  ];

  return (
    <ScrollView style={estilos.container}>
      <View style={estilos.conteudo}>

        <View style={estilos.headerTitulo}>
          <MaterialCommunityIcons name="ghost" size={35} color="#58A6FF" />
          <Text style={estilos.titulo}>Terror</Text>
        </View>

        <View style={estilos.card}>
          <Text style={estilos.subtitulo}>O que são jogos de terror?</Text>

<Text style={estilos.texto}>
Jogos de terror criam experiências de medo, suspense e tensão psicológica.
</Text>

<Text style={estilos.subtitulo}>Características</Text>
<Text style={estilos.texto}>
• Ambientes sombrios{"\n"}
• Sons assustadores{"\n"}
• Poucos recursos{"\n"}
• Sensação de vulnerabilidade
</Text>

<Text style={estilos.subtitulo}>Exemplos</Text>
<Text style={estilos.texto}>
Resident Evil, Silent Hill, Outlast, Amnesia, Dead Space
</Text>
        </View>

        <View style={estilos.card}>
          <TextInput
            style={estilos.input}
            placeholder="Seu jogo favorito..."
            value={favorito}
            onChangeText={setFavorito}
          />

          <Text style={estilos.resposta}>{favorito}</Text>
        </View>

        <View style={estilos.card}>
          <FlatList
            data={jogos}
            keyExtractor={(item) => item.id}
            scrollEnabled={false}
            renderItem={({ item }) => (
              <Text style={estilos.itemLista}>• {item.nome}</Text>
            )}
          />
        </View>

      </View>
    </ScrollView>
  );
}