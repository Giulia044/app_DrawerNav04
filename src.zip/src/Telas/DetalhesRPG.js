import React from 'react';
import { ScrollView, View, Text, Image } from 'react-native';

import estilos from '../styles/estilos';

export default function DetalhesRPG() {
  return (
    <ScrollView style={estilos.container}>
      <View style={estilos.conteudo}>

        <Image
          source={require('../imagens/witcher.avif')}
          style={estilos.imagemDetalhe}
        />

        <Text style={estilos.titulo}>The Witcher 3</Text>

        <View style={estilos.card}>
          <Text style={estilos.texto}>
            Desenvolvido pela CD Projekt Red, é um dos RPGs mais premiados da história.
          </Text>
        </View>

        <View style={estilos.card}>
          <Text style={estilos.texto}>
            Lançamento: 2015{"\n"}
            Nota: 93 Metacritic{"\n"}
            Gênero: RPG de mundo aberto
          </Text>
        </View>

      </View>
    </ScrollView>
  );
}