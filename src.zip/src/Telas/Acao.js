import React, { useState } from 'react';
import { ScrollView, View, Text, Image } from 'react-native';

import Slider from '@react-native-community/slider';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import estilos from '../styles/estilos';

export default function Acao() {
  const [nota, setNota] = useState(7);

  const nivel = () => {
    if (nota <= 3) return 'Iniciante';
    if (nota <= 7) return 'Jogador Casual';
    return 'Veterano da Ação';
  };

  return (
    <ScrollView style={estilos.container}>
      <View style={estilos.conteudo}>

        <View style={estilos.headerTitulo}>
          <MaterialCommunityIcons name="lightning-bolt" size={35} color="#58A6FF" />
          <Text style={estilos.titulo}>Ação</Text>
        </View>

        <View style={estilos.card}>
         <Text style={estilos.subtitulo}>O que são jogos de ação?</Text>

<Text style={estilos.texto}>
Jogos de ação focam em reflexos rápidos, combate dinâmico e desafios em tempo real.
</Text>

<Text style={estilos.subtitulo}>Características</Text>
<Text style={estilos.texto}>
• Combate intenso{"\n"}
• Jogabilidade rápida{"\n"}
• Precisão e reflexo{"\n"}
• Sequências cinematográficas
</Text>

<Text style={estilos.subtitulo}>Exemplos</Text>
<Text style={estilos.texto}>
God of War, GTA V, Devil May Cry 5, Spider-Man, DOOM Eternal
</Text>
        </View>

        <Text style={estilos.texto}>Nota: {nota}/10</Text>

        <Slider
          minimumValue={0}
          maximumValue={10}
          step={1}
          value={nota}
          onValueChange={setNota}
        />

        <Text style={estilos.resposta}>{nivel()}</Text>

      </View>
    </ScrollView>
  );
}