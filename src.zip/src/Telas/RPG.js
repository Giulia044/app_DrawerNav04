import React, { useState } from 'react';
import { ScrollView, View, Text, Switch, TouchableOpacity } from 'react-native';

import { MaterialCommunityIcons } from '@expo/vector-icons';
import estilos from '../styles/estilos';

export default function RPG({ navigation }) {
  const [gostaRPG, setGostaRPG] = useState(true);

  return (
    <ScrollView style={estilos.container}>
      <View style={estilos.conteudo}>

        <View style={estilos.headerTitulo}>
          <MaterialCommunityIcons name="sword-cross" size={35} color="#58A6FF" />
          <Text style={estilos.titulo}>RPG</Text>
        </View>

        <View style={estilos.card}>
          <Text style={estilos.subtitulo}>O que é RPG?</Text>

<Text style={estilos.texto}>
RPG (Role Playing Game) é um gênero onde o jogador controla um personagem dentro de uma narrativa, com evolução ao longo do jogo.
</Text>

<Text style={estilos.subtitulo}>Características</Text>
<Text style={estilos.texto}>
• Evolução de personagem{"\n"}
• Sistema de níveis e habilidades{"\n"}
• Escolhas que afetam a história{"\n"}
• Missões principais e secundárias
</Text>

<Text style={estilos.subtitulo}>Exemplos</Text>
<Text style={estilos.texto}>
The Witcher 3, Skyrim, Elden Ring, Final Fantasy, Diablo
</Text>
        </View>

        <Switch value={gostaRPG} onValueChange={setGostaRPG} />

        <Text style={estilos.resposta}>
          {gostaRPG ? 'Você gosta de RPG!' : 'Prefere outros gêneros'}
        </Text>

        <TouchableOpacity
          style={estilos.botao}
          onPress={() => navigation.navigate('Detalhes RPG')}
        >
          <MaterialCommunityIcons name="book-open-page-variant" size={22} color="#FFF" />
          <Text style={estilos.textoBotao}>Ver Detalhes</Text>
        </TouchableOpacity>

      </View>
    </ScrollView>
  );
}