import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

import RPG from '../Telas/RPG';
import DetalhesRPG from '../Telas/DetalhesRPG';

const Stack = createNativeStackNavigator();

export default function RPGStack() {
  return (
    <Stack.Navigator>
      <Stack.Screen
        name="RPG Home"
        component={RPG}
        options={{ headerShown: false }}
      />

      <Stack.Screen
        name="Detalhes RPG"
        component={DetalhesRPG}
      />
    </Stack.Navigator>
  );
}