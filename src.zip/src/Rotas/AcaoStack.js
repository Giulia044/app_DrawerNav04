import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

import Acao from '../Telas/Acao';

const Stack = createNativeStackNavigator();

export default function AcaoStack() {
  return (
    <Stack.Navigator>
      <Stack.Screen
        name="Ação Home"
        component={Acao}
        options={{ headerShown: false }}
      />
    </Stack.Navigator>
  );
}