import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

import Terror from '../Telas/Terror';

const Stack = createNativeStackNavigator();

export default function TerrorStack() {
  return (
    <Stack.Navigator>
      <Stack.Screen
        name="Terror Home"
        component={Terror}
        options={{ headerShown: false }}
      />
    </Stack.Navigator>
  );
}