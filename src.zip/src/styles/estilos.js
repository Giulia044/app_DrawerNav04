import { StyleSheet } from 'react-native';

export default StyleSheet.create({

  container: {
    flex: 1,
    backgroundColor: '#0B0F14', // mais Steam-like
  },

  conteudo: {
    padding: 16,
    paddingBottom: 40,
  },

  headerTitulo: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
    marginBottom: 18,
  },

  titulo: {
    fontSize: 28,
    fontWeight: '800',
    color: '#FFFFFF',
    letterSpacing: 0.5,
  },

  // 🎴 CARD estilo Steam
  card: {
    backgroundColor: '#151B23',
    borderRadius: 14,
    padding: 16,
    marginBottom: 14,

    borderWidth: 1,
    borderColor: '#222B36',
  },

  texto: {
    color: '#C7D5E0',
    fontSize: 15,
    lineHeight: 22,
  },

  subtitulo: {
    color: '#66C0F4',
    fontSize: 18,
    fontWeight: '700',
    marginBottom: 8,
  },

  resposta: {
    color: '#A1E3A1',
    fontSize: 16,
    fontWeight: '600',
    marginTop: 10,
    textAlign: 'center',
  },

  botao: {
    backgroundColor: '#1B2838',
    padding: 14,
    borderRadius: 10,

    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,

    borderWidth: 1,
    borderColor: '#2A475E',
    marginTop: 10,
  },

  textoBotao: {
    color: '#66C0F4',
    fontWeight: '700',
    fontSize: 15,
  },

  // 🖼 IMAGEM estilo Steam (NÃO estoura mais)
  imagemDetalhe: {
    width: '100%',
    height: 220,
    borderRadius: 12,
    marginBottom: 14,

    resizeMode: 'cover', // evita esticar errado
  },

  // 🔤 INPUT mais acessível
  input: {
    backgroundColor: '#0F141B',
    borderWidth: 1,
    borderColor: '#2A475E',
    borderRadius: 10,

    padding: 12,
    marginTop: 10,

    color: '#FFF',
    fontSize: 15,
  },

  itemLista: {
    color: '#C7D5E0',
    fontSize: 15,
    marginVertical: 6,
  },
subtitulo: {
  color: '#66C0F4',
  fontSize: 18,
  fontWeight: '700',
  marginTop: 12,
  marginBottom: 6,
},

texto: {
  color: '#C7D5E0',
  fontSize: 15,
  lineHeight: 22,
},
});